# CLDF directory

This directory contains the dataset formatted as [CLDF dataset](https://cldf.clld.org).
